from Crypto.Hash import SHA3_256
from Crypto.Hash import SHA3_256

h_obj = SHA3_256.new()
h_obj.update(b'test')
print(h_obj.hexdigest())

