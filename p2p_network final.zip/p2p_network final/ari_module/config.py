import os

from dotenv import load_dotenv
load_dotenv()

dest_server_address = os.getenv("DEST_SERVER_ADDRESS")
dest_server_port = int(os.getenv("DEST_SERVER_PORT"))

self_server_address = os.getenv("SELF_SERVER_ADDRESS")
self_server_port = int(os.getenv("SELF_SERVER_PORT"))

self_client_address = os.getenv("SELF_CLIENT_ADDRESS")
self_client_port = int(os.getenv("SELF_CLIENT_PORT"))

receiver_key = os.getenv("RECEIVER_KEY_FILE_NAME")
my_key = os.getenv("MY_KEY_FILE_NAME")

encryption_result = os.getenv("ENCRYPTION_RESULT_FILE_NAME")
saved_accounts = os.getenv("ACCOUNT_STORAGE_FILE_NAME")

rsa_private = os.getenv("RSA_PRIVATE_KEY_FILE_NAME")
rsa_public = os.getenv("RSA_PUBLIC_KEY_FILE_NAME")
rsa_encrypted = os.getenv("RSA_ENCRYPTED_TEXT_FILE_NAME")
