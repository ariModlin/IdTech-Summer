def d_hellman(modulus, base, private_key):
    my_number = (base ** private_key) % modulus
    return my_number


def caesar(key_shift, message):
    abc = "abcdefghijklmnopqrstuvwxyz"
    p1 = abc[:key_shift]
    p2 = abc[key_shift:]
    abc_shift = p2 + p1
    encrypted_message = ""
    for i in range(len(message)):
        letter_index = abc.find(message[i])
        if letter_index == -1:
            encrypted_message += " "
        else:
            encrypted_message += abc_shift[letter_index]
    # print(encrypted_message)
    return encrypted_message


def caesar_decrypt(key_shift, e_message):
    abc = "abcdefghijklmnopqrstuvwxyz"
    p1 = abc[:key_shift]
    p2 = abc[key_shift:]
    abc_shift = p2 + p1
    decrypted_message = ""
    for i in range(len(e_message)):
        letter_index = abc_shift.find(e_message[i])
        if letter_index == -1:
            decrypted_message += " "
        else:
            decrypted_message += abc[letter_index]
    return decrypted_message
