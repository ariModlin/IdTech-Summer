import ari_module.crypto_algos as algos
import pickle
from Crypto.Hash import SHA3_256
from os import path
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from ari_module.config import my_key, receiver_key, self_client_address, self_client_port, encryption_result, \
    saved_accounts, rsa_private, rsa_public, rsa_encrypted
server = "{}:{}".format(self_client_address, self_client_port)


def sign_in(account, logged_in):
    accounts = []  # creates an empty array of accounts
    if path.exists(saved_accounts):
        with open(saved_accounts, "rb") as file_object:
            accounts = pickle.load(file_object)
            # loads all the info from saved_accounts into the array "accounts"
    h_obj = SHA3_256.new()
    if account == "y":
        num = None
        usernames = [item["username"] for item in accounts]  # creates an array of all usernames
        username = input("input username: ")
        for idx in range(len(usernames)):
            if username == usernames[idx]:
                num = idx
                # searches the array of usernames for the user input and returns the value as an int
                break
            else:
                continue
        password = input("input password: ")
        h_obj.update(bytes(password, encoding="UTF-8"))
        password_hash = h_obj.hexdigest()
        # takes the password and creates a hash
        if password_hash == accounts[num]["password"]:
            # sees if the password hash matches the password associated with the username
            logged_in = True
        elif password_hash != accounts[num]["password"]:
            logged_in = False
    elif account == "n":
        # creates an account, appends it to the array of accounts and dumps it into saved_accounts
        username = input("create a username: ")
        password = input("create a password: ")
        h_obj.update(bytes(password, encoding="UTF-8"))
        password_hash = h_obj.hexdigest()
        account = {"username": username, "password": password_hash}
        accounts.append(account)
        with open(saved_accounts, "wb") as file_object:
            pickle.dump(accounts, file_object)
        logged_in = False
    return logged_in


def options():
    return (
          "Welcome to Ari's superior program. \n"
          "Enter 'send-kx' to begin key exchange \n" 
          "Enter 'reply-kx' to reply with your key \n"
          "Enter 'encrypt' to encrypt your message \n"
          "Enter 'decrypt' to decrypt the received message \n"
          "Enter 'rsa-key' to share public keys for RSA \n"
          "Enter 'refresh' to refresh the screen \n"
          "Enter 'show-options' to reshow this menu \n"
          )


def send_kx():
    public_mod = int(input("input the public modulus number: "))
    public_base = int(input("input the public base number: "))
    private_key = int(input("pick a number for your private key: "))
    destination_address = input("input the destination address: ")
    # asks the user for the following values and inputs it into the diffie hellman key exchange
    key = algos.d_hellman(public_mod, public_base, private_key)
    # returns the key for the first half of diffie hellman key exchange
    with open(my_key, "wb") as file_object:
        pickle.dump(key, file_object)   # puts the return value of diffie hellman (key) into the file my_key.pickle
    send = {"from": server, "to": destination_address, "command": "start-kx", "public_modulus": public_mod,
            "public_base": public_base, "encrypted_key": key}  # creates the message being sent
    return pickle.dumps(send)  # returns the information contained in send as a binary file to the other p2p_server


def reply_kx():
    with open(receiver_key, "rb") as file_object:
        result = pickle.load(file_object)  # loads the first key received from send_kx into "result"
    private_key = int(input("input private key: "))
    key = algos.d_hellman(result["public_modulus"], result["public_base"], private_key)
    # reruns diffie hellman to get the completed key
    send = {"to": result["from"], "from": result["to"], "public_modulus": result["public_modulus"],
            "public_base": result["public_base"], "command": "reply-kx", "encrypted_key": key}
    return pickle.dumps(send)  # sends the completed key


def encrypt():
    e_method = input("choose encryption method: caesar, RSA:   ")
    if e_method == "caesar":
        message = input(">>> write your message: ")
        private_key = int(input("input private key: "))
        # encrypts a message using caesar cypher
        encrypted_message = caesar_encrypt(message, private_key)
        return encrypted_message
    if e_method == "RSA":
        message = input(">>> write your message: ")
        encrypted_message = rsa_encrypt(message)
        return encrypted_message


def decrypt():
    d_method = input("choose decryption method: caesar, RSA:   ")
    if d_method == "caesar":
        # decrypts the message using caesar cypher
        decrypted_message = caesar_decrypt()
        return decrypted_message
    elif d_method == "RSA":
        decrypted_message = rsa_decrypt()
        return decrypted_message

def caesar_encrypt(message, private_key):
    with open(receiver_key, "rb") as file_object:
        result = pickle.load(file_object)  # loads receiver_key received from send_kx into "result"
    key_num = (result["encrypted_key"] ** private_key) % result["public_modulus"]
    print(key_num)  # does diffie hellman exchange to find the shared key
    key_num = key_num % 26
    message = algos.caesar(key_num, message)  # runs caesar cypher using the message inputted and the shift
    send = {"to": result["from"], "from": result["to"], "command": "caesar-encrypt", "encrypted_text": message}
    return pickle.dumps(send)  # sends the completed key


def caesar_decrypt():
    private_key = int(input("input private key: "))
    with open(receiver_key, "rb") as file_object:
        result = pickle.load(file_object)  # loads receiver_key received from send_kx into "result"
    with open(encryption_result, "rb") as file_object:
        encrypted_message = pickle.load(file_object)  # retrieves the encrypted message from pickle
    key_num = (result["encrypted_key"] ** private_key) % result["public_modulus"]
    key_num = key_num % 26
    # finds the key shift using the shared diffie hellman number
    message = algos.caesar_decrypt(key_num, encrypted_message["encrypted_text"])
    return message


def share_pub_keys():
    with open(receiver_key, "rb") as file_object:
        result = pickle.load(file_object)  # loads the first key received from send_kx into "result"
    key = RSA.generate(2048)
    private_key = key.export_key('PEM')
    public_key = key.publickey().exportKey('PEM')
    with open(rsa_private, "wb") as file_object:
        pickle.dump(private_key, file_object)   # puts the private key into rsa_private.pickle
    send = {"to": result["from"], "from": result["to"], "command": "rsa-key", "public_key": public_key}
    return pickle.dumps(send)  # sends the completed key


def rsa_encrypt(message):
    message = str.encode(message)
    with open(receiver_key, "rb") as file_object:
        result = pickle.load(file_object)  # contains to and from address
    with open(rsa_public, "rb") as file_object:
        rsa_pub = pickle.load(file_object)  # loads the public key
    key = rsa_pub["public_key"]
    rsa_public_key = RSA.importKey(key)
    rsa_public_key = PKCS1_OAEP.new(rsa_public_key)
    encrypted_text = rsa_public_key.encrypt(message)
    send = {"to": result["from"], "from": result["to"], "command": "rsa-encrypt", "encrypted_text": encrypted_text}
    return pickle.dumps(send)


def rsa_decrypt():
    with open(rsa_private, "rb") as file_object:
        private_key = pickle.load(file_object)
    with open(rsa_encrypted, "rb") as file_object:
        received = pickle.load(file_object)
    rsa_private_key = RSA.importKey(private_key)
    rsa_private_key = PKCS1_OAEP.new(rsa_private_key)
    decrypted_text = str(rsa_private_key.decrypt(received["encrypted_text"]), encoding="UTF-8")
    return decrypted_text