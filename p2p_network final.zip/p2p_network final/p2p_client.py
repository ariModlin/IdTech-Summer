# echo-client.py

import trio
import ari_module.helpers as ari
from ari_module.config import dest_server_address, dest_server_port


# arbitrary, but:
# - must be in between 1024 and 65535
# - can't be in use by some other program on your computer
# - must match what we set in our echo server
# How much memory to spend (at most) on each call to recv. Pretty arbitrary,
# but shouldn't be too big or too small.
BUFSIZE = 16384


async def sender(client_stream):
    result = None
    print("sender: started!")
    while True:
        command = input(">>> enter your command: ")
        if command == "send-kx":
            result = ari.send_kx()
        elif command == "reply-kx":
            result = ari.reply_kx()
        elif command == "encrypt":
            result = ari.encrypt()
        elif command == "decrypt":
            print("accessing decrypted message...")
            d_message = ari.decrypt()
            print("decrypting...")
            print("message decrypted: ")
            print(d_message)
        elif command == "rsa-key":
            result = ari.share_pub_keys()
        elif command == "rsa-decryption":
            # result = ari.rsa_decrypt()
            pass
        elif command == "refresh":
            print("refreshing...")
            await trio.sleep(2)
        elif command == "show-options":
            print(ari.options())
        print("sender: sending {!r}".format(command))
        if result:
            await client_stream.send_all(result)
        await trio.sleep(1)


async def parent():
    logged_in = False
    while not logged_in:
        account = (input("do you have an account y/n?  "))
        logged_in = ari.sign_in(account, logged_in)
    while logged_in:
        print(logged_in)
        print("parent: connecting to: {}:{}".format(dest_server_address, dest_server_port))
        client_stream = await trio.open_tcp_stream(dest_server_address, dest_server_port)
        print(ari.options())
        async with client_stream:
            async with trio.open_nursery() as nursery:
                print("parent: spawning sender...")
                nursery.start_soon(sender, client_stream)

trio.run(parent)
